# E.D.N. — видео с прозрачным фоном

Обработано предоставленное видео «Девочка и кукла на лонгсливе.mp4»: 121 кадр, 24 кадра/с, 5,041667 секунды, 1216 × 1792. Звуковой дорожки в исходнике нет. Движение, камера и длительность сохранены; кадры не генерировались заново.

Фон выделен методом видеоматтинга с учётом предыдущих кадров. Контур слегка сужен, сглажен и очищен от цветной каймы. Цвет внутри силуэта сохранён из исходника. Детали, уже потерянные в исходном сжатом видео, не восстанавливались искусственно.

## Файлы

- `edn-girl-transparent.webm` — видео VP9 с настоящим альфа-каналом; для прямой вставки в поддерживающий браузер, например Chrome или Firefox.
- `edn-girl-alpha-packed.mp4` — совместимый H.264 для комплектного компонента. Слева цвет, справа маска прозрачности. **При обычном открытии MP4 видны обе половины. Прозрачность из него восстанавливает `transparent-player.js`.**
- `transparent-player.js` — лёгкий компонент WebGL, без библиотек и внешних запросов. Позволяет использовать MP4 в браузерах с H.264 и WebGL, включая Safari; Safari отдельно в этой среде не проверялся.
- `poster.png` — прозрачная обложка из первого обработанного кадра, в исходном разрешении.
- `animation-preview.webp` — анимированный WebP с прозрачностью, 608 × 896. Его можно вставлять обычным `<img>`; это уменьшенная версия для предпросмотра. Полное разрешение сохранено в WebM и комплектном MP4.
- `index.html` — просмотр на четырёх фонах.
- `embed.html` — только анимация на прозрачном фоне, для iframe.

## Вставка на сайт

Загрузите всю папку рядом с файлами сайта. Рекомендуемый вариант:

```html
<script src="/EDN-transparent-video/transparent-player.js" defer></script>
<edn-transparent-video
  src="/EDN-transparent-video/edn-girl-alpha-packed.mp4"
  poster="/EDN-transparent-video/poster.png"
  aria-label="Модель в лонгсливе E.D.N."
  style="width:min(100%,480px)">
</edn-transparent-video>
```

Компонент сохраняет пропорции, воспроизводится без звука и повторяется. При включённом `prefers-reduced-motion` показан неподвижный первый кадр; запустить можно вызовом `.play()`. Для запрета автозапуска добавьте `autoplay="false"`. Методы `.play()` и `.pause()` доступны для ваших кнопок.

Если нужны только Chrome/Firefox, можно вставить WebM напрямую:

```html
<video autoplay muted loop playsinline
  poster="/EDN-transparent-video/poster.png"
  style="width:min(100%,480px);height:auto;display:block">
  <source src="/EDN-transparent-video/edn-girl-transparent.webm" type="video/webm">
</video>
```

Для iframe:

```html
<iframe src="/EDN-transparent-video/embed.html"
  title="Модель E.D.N."
  allow="autoplay"
  style="width:100%;height:700px;border:0;background:transparent">
</iframe>
```

Для простого использования анимированного WebP:

```html
<picture>
  <source media="(prefers-reduced-motion: reduce)"
    srcset="/EDN-transparent-video/poster.png">
  <img src="/EDN-transparent-video/animation-preview.webp"
    alt="Модель E.D.N." width="608" height="896"
    style="max-width:100%;height:auto">
</picture>
```

`EDN-video-preview.html`, предоставленный отдельно от папки, — автономная страница просмотра. В ней уже встроены видео и обложка; после открытия можно сохранить исходный WebM кнопкой «Скачать WebM».

Для версии MP4 + WebGL разместите видео и скрипт на одном домене через HTTP/HTTPS. При отдельном домене видео потребуется разрешение CORS; открытие локальных файлов через `file://` может блокироваться браузером. При недоступном WebGL остаётся PNG-обложка. Загрузка на хостинг в рамках обработки видео не выполнялась.

Обработка выполнена локально: Robust Video Matting (PeterL1n/RobustVideoMatting, модель MobileNetV3 ONNX), очистка контура и FFmpeg. Пользовательское видео не отправлялось стороннему сервису обработки.
