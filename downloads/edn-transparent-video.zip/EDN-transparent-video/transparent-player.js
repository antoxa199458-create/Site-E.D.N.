// E.D.N. — playback of color + alpha packed horizontally in one MP4.
// Left half: RGB. Right half: grayscale alpha. No third-party dependencies.
class EdnTransparentVideo extends HTMLElement {
  connectedCallback() {
    if (this.shadowRoot) return;
    const root = this.attachShadow({mode:'open'});
    root.innerHTML = `<style>
      :host{display:block;position:relative;aspect-ratio:1216/1792;background:transparent}
      canvas,img{position:absolute;inset:0;display:block;width:100%;height:100%;object-fit:contain}
      img{transition:opacity .15s}img.ready{opacity:0;pointer-events:none}
      video{position:absolute;width:1px;height:1px;opacity:0;pointer-events:none}
    </style><canvas aria-hidden="true"></canvas><img alt=""><video muted playsinline loop preload="auto"></video>`;
    this.canvas = root.querySelector('canvas');
    this.poster = root.querySelector('img');
    this.poster.src = this.getAttribute('poster') || 'poster.png';
    this.poster.alt = this.getAttribute('aria-label') || 'Модель E.D.N.';
    this.media = root.querySelector('video');
    this.media.muted = true;
    this.media.playsInline = true;
    this.canvas.width = Number(this.getAttribute('width')) || 1216;
    this.canvas.height = Number(this.getAttribute('height')) || 1792;
    this.style.aspectRatio = `${this.canvas.width}/${this.canvas.height}`;
    this.reducedMotion = matchMedia('(prefers-reduced-motion: reduce)').matches;
    this.abort = new AbortController();
    this.media.addEventListener('error', () => this.fail('Не удалось открыть видео.'), {signal:this.abort.signal});
    for (const event of ['play','pause']) this.media.addEventListener(event, () => {
      this.dispatchEvent(new Event(event));
    }, {signal:this.abort.signal});
    try { this.setupRenderer(); }
    catch (error) { this.fail('В этом браузере недоступен WebGL.'); return; }
    this.media.addEventListener('loadeddata', () => {
      this.draw();
      this.watchFrames();
      if (!this.reducedMotion && this.getAttribute('autoplay') !== 'false') this.play().catch(() => {});
    }, {once:true,signal:this.abort.signal});
    this.media.addEventListener('seeked', () => this.draw(), {signal:this.abort.signal});
    document.addEventListener('visibilitychange', () => {
      if (document.hidden) { this.resumeVisible = !this.media.paused; this.media.pause(); }
      else if (this.resumeVisible) { this.resumeVisible = false; this.play().catch(() => {}); }
    }, {signal:this.abort.signal});
    this.media.src = this.getAttribute('src') || 'edn-girl-alpha-packed.mp4';
  }
  setupRenderer() {
    const gl = this.canvas.getContext('webgl', {alpha:true,premultipliedAlpha:false,antialias:false});
    if (!gl) throw Error('WebGL unavailable');
    this.gl = gl;
    const shader = (type, source) => {
      const s = gl.createShader(type); gl.shaderSource(s,source); gl.compileShader(s);
      if(!gl.getShaderParameter(s,gl.COMPILE_STATUS)) throw Error(gl.getShaderInfoLog(s));
      return s;
    };
    const vertex = shader(gl.VERTEX_SHADER, `attribute vec2 pos;varying vec2 uv;
      void main(){gl_Position=vec4(pos,0.,1.);uv=vec2((pos.x+1.)*.5,(1.-pos.y)*.5);}`);
    const fragment = shader(gl.FRAGMENT_SHADER, `precision highp float;varying vec2 uv;
      uniform sampler2D frame;uniform float imageWidth;
      void main(){
        float x=clamp(uv.x*.5,.25/imageWidth,.5-.25/imageWidth);
        vec3 color=texture2D(frame,vec2(x,uv.y)).rgb;
        float mask=texture2D(frame,vec2(x+.5,uv.y)).r;
        float alpha=clamp((mask-.008)/.984,0.,1.);
        gl_FragColor=vec4(color,alpha);
      }`);
    const program = gl.createProgram(); gl.attachShader(program,vertex); gl.attachShader(program,fragment);
    gl.linkProgram(program); if(!gl.getProgramParameter(program,gl.LINK_STATUS))throw Error('WebGL link failed');
    gl.useProgram(program);
    const buffer=gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER,buffer);
    gl.bufferData(gl.ARRAY_BUFFER,new Float32Array([-1,-1,1,-1,-1,1,-1,1,1,-1,1,1]),gl.STATIC_DRAW);
    const location=gl.getAttribLocation(program,'pos'); gl.enableVertexAttribArray(location);
    gl.vertexAttribPointer(location,2,gl.FLOAT,false,0,0);
    gl.uniform1f(gl.getUniformLocation(program,'imageWidth'),this.canvas.width);
    gl.uniform1i(gl.getUniformLocation(program,'frame'),0);
    this.texture=gl.createTexture(); gl.bindTexture(gl.TEXTURE_2D,this.texture);
    for(const p of [gl.TEXTURE_MIN_FILTER,gl.TEXTURE_MAG_FILTER])gl.texParameteri(gl.TEXTURE_2D,p,gl.LINEAR);
    for(const p of [gl.TEXTURE_WRAP_S,gl.TEXTURE_WRAP_T])gl.texParameteri(gl.TEXTURE_2D,p,gl.CLAMP_TO_EDGE);
    gl.viewport(0,0,this.canvas.width,this.canvas.height);
  }
  draw() {
    if(!this.gl || !this.media || this.media.readyState<2)return;
    try{
      const gl=this.gl;
      gl.bindTexture(gl.TEXTURE_2D,this.texture);
      gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,this.media);
      gl.drawArrays(gl.TRIANGLES,0,6);
      if(!this.ready){this.ready=true;this.poster.classList.add('ready');this.dispatchEvent(new Event('ready'));}
    }catch(error){this.fail('Для воспроизведения разместите папку на сайте через HTTPS.');}
  }
  watchFrames() {
    const tick=()=>{if(!this.isConnected||this.failed)return;this.draw();this.watchFrames();};
    if('requestVideoFrameCallback' in this.media)this.callback=this.media.requestVideoFrameCallback(tick);
    else this.callback=requestAnimationFrame(tick);
  }
  get paused(){return !this.media || this.media.paused;}
  play(){return this.media.play();}
  pause(){this.resumeVisible=false;this.media.pause();}
  fail(message){
    this.failed=true;this.poster.classList.remove('ready');
    if(this.media)this.media.pause();
    this.dispatchEvent(new CustomEvent('player-error',{detail:message}));
  }
  disconnectedCallback(){
    this.abort?.abort();this.media?.pause();
    if(this.media?.cancelVideoFrameCallback)this.media.cancelVideoFrameCallback(this.callback);
    else cancelAnimationFrame(this.callback);
    this.gl?.getExtension('WEBGL_lose_context')?.loseContext();
  }
}
customElements.define('edn-transparent-video',EdnTransparentVideo);
